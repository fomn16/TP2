module Modules.KwicModule.KwicModule (kwic) where

import Modules.StringOperatorsModule.StringOperatorsModule (unCapitalize, lettersOnly, separateStringInLines, removeWords)
import Modules.ListOperatorsModule.ListOperatorsModule (secondTermsFromPair, quickSort, separateInTerms)

data Default = Default

--separa as linhas da primeira string de entrada e aplica process lines em cada uma, concatenando as saídas
kwic :: String -> String -> String
kwic a b = apply processLines (separateStringInLines a) b Default
    where
        apply _ [] _ _ = ""
        apply f (a:as) b instanceID = (f a b instanceID) ++ "\n" ++ apply f as b instanceID

--processa as strings fornecidas de acordo com o algoritmo Kwic implementado

class ProcessLines instanceID where
    processLines ::  String-> String -> instanceID -> String

instance ProcessLines Default where
    processLines textContents stopwordContents instanceID = generateText (secondTermsFromPair sortedKeywords) separatedText 0 0 instanceID
        where                                                                       --passos:
            sortedKeywords = quickSort unsortedKeywords                             --  6 : ordena palavras restantes do título
            unsortedKeywords = removeWords filteredText stopwords                   --  5 : retira stopwords das palavras do título, "anotando" seus lugares originais
            filteredText = map lettersOnly uncapitalizedText                        --  4 : retira qualquer coisa que não letras minúsculas das palavras do título
            uncapitalizedText = map unCapitalize separatedText                      --  3 : retira letras maiúsculas das palavras do título substituindo-as por minúsculas
            stopwords = separateInTerms (filter (/= ' ') stopwordContents) [] ' '   --  2 : separa string de stopwords em palavras
            separatedText = separateInTerms textContents [] ' '                     --  1 : separa string do título em palavras

class GenerateText instanceID where
    generateText :: [Int] -> [String] -> Int -> Int -> instanceID -> String

--monta uma string dadas as localizações das palavras chave da string de origem, a string original, 0 e 0 respectivamente.
instance GenerateText Default where
    generateText _ [] _ _ instanceID = ""
    generateText (i:is) b 0 _ instanceID = (b !! i) ++ (generateText [i+1] b 1 (length b) instanceID) ++ "/" ++ (generateText [0] b 1 i instanceID) ++ "\n" ++ generateText is b 0 0 instanceID
    generateText (i:is) b 1 n instanceID --escreve o que vem entre as posições i e n na lista b
        |i < n = " " ++ b !! i ++ generateText [i+1] b 1 n instanceID
        |otherwise = ""
